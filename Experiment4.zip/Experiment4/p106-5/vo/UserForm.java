package vo;

public class UserForm {
	private String username="";	
	private String pwd="";
	private String sex="";
	private String[] affect=null;
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsername() {
		return username;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPwd() {
		return pwd;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSex() {
		return sex;
	}
	public void setAffect(String[] affect) {
		this.affect = affect;
	}
	public String[] getAffect() {

		return affect;
	}
}
